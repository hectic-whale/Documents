#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

int mean (char *filename)
{
    //We initiliaze the string where the each line will be stored
    char str[10]={0};
	float bum=0;
   //Process to open file
  //  char *filename = "Untitled.txt";
  //Pointer to file
    FILE *fp = fopen(filename, "r");
      //Counter to read the number of rows
    int i=0, j=0, k=0, e=0;
     //Delimiter decla, ration
    char delims[] = " ";
    char *result = NULL; 
      // Counter for the number of columns
    int count = 0;
    //If file can not be opened, return an error.
    if (fp == NULL)
    {
        printf("Error: could not open file %s", filename);
        return 1;
    }
    // reading line by line, max lenght 1000 bytes
    const unsigned MAX_LENGTH = 10000;
    char buffer[MAX_LENGTH];

        //while there are more lines
    while (fgets(buffer, MAX_LENGTH, fp)){
                   //If we are in the first line then we proceed to read the number of columns
        if (i==0){
         //The result of dividing the buffer using the delimiter " " is stored in result
            result = strtok( buffer, delims );
            //reads the number of columns by counting how many times it stops due to the limiters
            while( result != NULL ) {
                count ++;
                result = strtok( NULL, delims );
            }
           


        }
    i=i+1;
        }
		
		
    //Close the file
    fclose(fp);

    float bidimensionalArray[i][count];



    fp = fopen(filename, "r");

    //stores the rows
    while (j < i) {
      //stores the columns
      while ( k < count) {
          //Get each value from the file
          fscanf(fp, "%s", str);
              bum = atof(str);
			   bidimensionalArray[j][k]=bum;
			   k++;
        }
		k=0;
		j++;

    }
	
	k=0;
	j=0;
    //Calculate mean
     float mean[i];
     
	 #pragma omp for
	   
	 for(j=0; j < i; j++ )
	 {
		 mean[j]=0;
	 }
    
	 
	 j=0;
	 
#pragma omp for
     for( j=0; j< i; j++) {
         #pragma omp critical
		 {
         for(  k=0; k < count; k++) {
                   mean[j] += bidimensionalArray[j][k];
 	
           }
	   }
	  
        mean[j] = mean[j]/count; 
		 }

 
    
   
	
	j=0;
   while(j<i){
               printf("%f ", mean[j]);
			   j++;
     }

    return 0;
  }