#include <stdio.h>
#include "lib/libct.h"
#include <string.h>

int main (void)
{
    char str[100];
    printf("Enter the file name: ");
    scanf("%s", str);

    // Check if the string fits the format "string.txt"
    int len = strlen(str);
    if  (strcmp(str + len - 4, ".txt") != 0) {
        printf("Invalid string. Must be in the format \"string.txt\".\n");
        return 1;
    }

    // Print the string using another function
    mean(str);

    return 0;

return 0;
}